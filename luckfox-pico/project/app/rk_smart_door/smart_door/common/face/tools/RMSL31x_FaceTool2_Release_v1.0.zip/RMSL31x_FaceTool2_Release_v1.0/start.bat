@echo off
set TCL_PATH=bin\IronTcl\bin
set PATH=%PATH%;%TCL_PATH%

start wish86t  FaceTool2.tcl