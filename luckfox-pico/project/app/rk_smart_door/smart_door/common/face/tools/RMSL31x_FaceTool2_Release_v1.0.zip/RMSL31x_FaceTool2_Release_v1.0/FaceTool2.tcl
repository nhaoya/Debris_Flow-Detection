#!/usr/bin/env tclsh

package require Tk
# force utf-8 on windows wrapped exe (freewrap workaround)
# if {$::tcl_platform(platform) eq "windows" && [encoding system] ne "utf-8" } {
  # encoding system utf-8
# }

# source "Azure-ttk-theme/azure.tcl"
# puts [ttk::style theme names]

#ttk::style theme use "clam"
# ----------------------------------------------------------------------------------------
# VARIABLES
set BOARD_STATUS_DISCON             0
set BOARD_STATUS_READY              1
set BOARD_STATUS_BUSY               2

namespace eval FT2 {
    variable conn_type              ""

    variable com_available          0
    variable com_port               ""
    variable com_baud               ""

    variable board_no_anwser        0
    variable board_status           0
    variable board_timeout          0

    variable board_version          "�̼��汾"

    variable enroll_username        "User 1"
    variable enroll_isadmin         0
    variable enroll_facedir         ""

    variable verify_auto            0
    variable verify_cnt             0
    variable verify_cntdown         0
    variable verify_facestate       0
    variable verify_livestate       0
    variable verify_userstate       -1

    variable capture_enable         0
    variable expected_livestate     "����"
    variable capture_path           "default"
    variable capture_save_path      ""
    variable capture_uid            0
    variable capture_num            0
    variable capture_r2r_num        0
    variable capture_r2f_num        0
    variable capture_f2f_num        0
    variable capture_f2r_num        0
    
    variable ft232_power            1
}

namespace eval ui {
    variable status_com             ""
    variable status_board           ""
    variable open_label             ""
    variable values_devices         [list]
    variable values_baudrates       [list 115200 1500000]
    variable enable_capture         0
    variable values_facedirs        [list "Middle" "Up" "Down" "Left" "Right"]
    variable values_face_status     [list "��������" "δ��⵽����" "����̫��" "����̫��" "����̫��" \
        "����̫��" "��������̫Զ" "��������̫��" "üë�ڵ�" "�۾��ڵ�" "�����ڵ�" "¼�������������" \
        "�ڱ���ģʽ��⵽����" "����״̬" "�ڱ���ģʽ�޷��ж���״̬"]

    variable values_live_status     [list "����" "����"]
    variable values_live_path       [list "fake" "real"]

    variable values_light           [list "Ĭ��" "����" "���" "���" "����" "ǿ��"]
    variable values_light_path      [list "X" "norLi" "sideLi" "backLi" "weakLi" "brightLi"]

    variable values_glass           [list "Ĭ��" "���۾�" "���۾�"]
    variable values_glass_path      [list "X" "yGls" "nGls"]

    variable values_mask            [list "Ĭ��" "A�۳��۾�" "B�۳����" "C�۳�����" \
        "D�۳���ͺͱ���" "E�۳��۾�����" "F�۳��۾��������"]
    variable values_mask_path       [list "X" "rmEye" "rmMth" "rmNse" "rmMN" "rmEN" "rmENM"]

    variable values_distence        [list "Ĭ��" "40" "60" "80"]
    variable values_distence_path   [list "X" "40" "60" "80"]

    variable values_attack          [list "Ĭ��" "�ֻ�" "ƽ��" "�ʼǱ�" "ֽ-��ͨ" "ֽ-�ƹ�" "ֽ-ͭ��" "ֽ-����" "���" "ͷģ"]
    variable values_attack_path     [list "X" "phone" "pad" "laptop" "paperNor" "paperYG" "paperTB" "paperLS" "3dmask" "headmd"]

    variable values_move            [list "Ĭ��" "��̬" "��̬"]
    variable values_move_path       [list "X" "static" "move"]

    variable values_makeup          [list "Ĭ��" "����" "��ױ" "����"]
    variable values_makeup_path     [list "X" "Fnormal" "Fmkup" "Fpaint"]

    variable values_replace         [list "Ĭ��" "�۾���ǩ" "�۾����ӱ�ǩ" "��ͱ�ǩ"]
    variable values_replace_path    [list "X" "addEye" "addEyeM" "addMth"]

    variable state_face             "����״̬"
    variable state_live             "����״̬"
    variable state_user             "�û����"
}

# ----------------------------------------------------------------------------------------
# PROCEDURES

# ----------------------------------------------------------------------------------------
# System functions -----------------------------------------------------------------------
proc logbox_output {text} {
    set log .log.text
    $log insert end "$text"
    $log see end
}

# Exit application
proc exitpgm {} {
    RMSL31xStop
    exit 0
}

proc set_board_status { stat } {
    global BOARD_STATUS_DISCON
    global BOARD_STATUS_READY
    global BOARD_STATUS_BUSY

    if { $stat == "discon" } {
        set FT2::board_status $BOARD_STATUS_DISCON
        set ui::status_board "Disconnected"
        .statusbar.board_stat configure -foreground red
    }

    if { $stat == "busy" } {
        set FT2::board_status $BOARD_STATUS_BUSY
        set ui::status_board "Executing..."
        .statusbar.board_stat configure -foreground blue
    }

    if { $stat == "ready" } {
        set FT2::board_status $BOARD_STATUS_READY
        set ui::status_board "Ready!"
        .statusbar.board_stat configure -foreground green
    }
}

proc update_verify_status { } {
    if { $FT2::verify_livestate == 1 } {
        set ui::state_live "����"
        .nb.fverify.fverstat.llivestat2 configure -background green
    } else {
        set ui::state_live "�ǻ���"
        .nb.fverify.fverstat.llivestat2 configure -background red
    }

    if { $FT2::verify_userstate == -1 } {
        set ui::state_user "δ֪�û�"
        .nb.fverify.fverstat.luserstat2 configure -background red
    } else {
        set ui::state_user "�û� ID:$FT2::verify_userstate"
        .nb.fverify.fverstat.luserstat2 configure -background green
    }

}

proc update_face_status { } {

    if { $FT2::verify_facestate == 0 } {
        .nb.fverify.fverstat.lfacestat2 configure -background green
    } else {
        .nb.fverify.fverstat.lfacestat2 configure -background red
    }

    set ui::state_face [lindex $ui::values_face_status $FT2::verify_facestate]
}

proc format_capture_path { } {
    set id0 [.nb.fcapture.flivcon.cbexplive current]
    set id1 [.nb.fcapture.fcapcon.cblight   current]
    set id2 [.nb.fcapture.fcapcon.cbglass   current]
    set id3 [.nb.fcapture.fcapcon.cbmask    current]
    set id4 [.nb.fcapture.fcapcon.cbatk     current]
    set id5 [.nb.fcapture.fcapcon.cbmove    current]
    set id6 [.nb.fcapture.fcapcon.cbmkup    current]
    set id7 [.nb.fcapture.fcapcon.cbdist    current]
    set id8 [.nb.fcapture.fcapcon.cbrepl    current]

    set str0 [lindex $ui::values_live_path   $id0]
    set str1 [lindex $ui::values_light_path  $id1]
    set str2 [lindex $ui::values_glass_path  $id2]
    set str3 [lindex $ui::values_mask_path   $id3]
    set str4 [lindex $ui::values_attack_path $id4]
    set str5 [lindex $ui::values_move_path   $id5]
    set str6 [lindex $ui::values_makeup_path $id6]
    set str7 [lindex $ui::values_distence_path $id7]
    set str8 [lindex $ui::values_replace_path  $id8]

    #logbox_output [format "%s_%s_%s_%s_%s_%s" $str1 $str2 $str3 $str4 $str5 $str6]
    set FT2::capture_path [format "%s_%s_%s_%s_%s_%s_%s_%s_%s_%s" $str0 $FT2::capture_uid $str1 $str2 $str6 $str4 $str5  $str3 $str8 $str7]
}

proc set_capture_path { } {
    if { [string length $FT2::capture_path]  == 0 } {
        logbox_output "Warning: empty path!\n"
        set FT2::capture_path "default"
    }
    if { [file exists "capture"] == 0 } {
        logbox_output "make dir \"capture\"!\n"
        file mkdir "capture"
    }
    if { [file exists "capture/${FT2::capture_path}"] == 0 } {
        logbox_output "make dir \"capture/${FT2::capture_path}\"!\n"
        file mkdir "capture//${FT2::capture_path}"
    }

    logbox_output "set path to \"capture/${FT2::capture_path}\" .\n"

    set FT2::capture_save_path "capture/${FT2::capture_path}"

    set FT2::capture_r2r_num   0
    set FT2::capture_r2f_num   0
    set FT2::capture_f2f_num   0
    set FT2::capture_f2r_num   0
}

proc open_capture_path { } {
    if { [string length $FT2::capture_save_path]  == 0 } {
        logbox_output "Error: Please set path!\n"
        return
    }
    exec {*}[auto_execok start] [file nativename $FT2::capture_save_path]
}

proc save_capture_statistics { } {

    set r_all [expr $FT2::capture_r2r_num + $FT2::capture_r2f_num]
    set f_all [expr $FT2::capture_f2f_num + $FT2::capture_f2r_num]

    set line1 [format "RALL:%3d R2R:%3d R2F:%3d" $r_all $FT2::capture_r2r_num $FT2::capture_r2f_num]
    set line2 [format "FALL:%3d F2F:%3d F2R:%3d\n" $f_all $FT2::capture_f2f_num $FT2::capture_f2r_num]

    logbox_output "\[statistics\] $line1 \n"
    logbox_output "\[statistics\] $line2 \n"

    if { [string length $FT2::capture_save_path]  > 0 } {
        set fp [open "$FT2::capture_save_path/0statistics.txt" w]
        puts $fp $line1
        puts $fp $line2
        close $fp
    }
}

proc start_capture { } {
    if { [string length $FT2::capture_save_path]  == 0 } {
        logbox_output "Error: Please set path!\n"
        return
    }

    if { [string is integer $FT2::verify_cnt] != 1 } {
        logbox_output "Error: Auto verify cnt not an integer!\n"
        return
    }

    set FT2::verify_cntdown $FT2::verify_cnt
    set FT2::capture_enable 1
    rmsl31x_command_verify
}

proc start_verify { } {
    if { [string is integer $FT2::verify_cnt] != 1 } {
        logbox_output "Error: Auto verify cnt not an integer!\n"
        return
    }

    set FT2::verify_cntdown $FT2::verify_cnt
    set FT2::capture_enable 0
    rmsl31x_command_verify
}

# set connection type
proc select_connection_type {} {
    #logbox_output "conn_type $FT2::conn_type\n"
    if { $FT2::conn_type == "Serial" } {
        set ui::open_label "Serial Num:"
    }
    if { $FT2::conn_type == "FT232" } {
        set ui::open_label "FT232 SN:"
    }
}

# set connection type
proc enum_connection_devices {} {
    #logbox_output "conn_type $FT2::conn_type\n"
    catch { CI_ConnEnum $FT2::conn_type } res


    logbox_output "\[$FT2::conn_type\]: found [llength $res] devices.\n"
    #set ui::values_devices $res
    .nb.fconnect.fopen.cbopen configure -values $res

    if { [llength $res] > 0 } {
        .nb.fconnect.fopen.cbopen current 0
    }
}

proc ft232_set_power {} {
    
    if { $FT2::conn_type == "FT232" } {
        if { $FT2::ft232_power } {
            logbox_output "ft232 power on.\n"
        } else {
            logbox_output "ft232 power off.\n"
        }
        
        catch { CI_ConnSetPower $FT2::conn_type $FT2::ft232_power } res
    } else {
        logbox_output "ERROR: Only FT232 support power control!\n"
    }
}

proc rmsl31x_start {} {

    set arg1 $FT2::com_port
    set arg2 $FT2::com_baud

    if { [string length $arg1]  == 0 } { return }
    if { [string length $arg2]  == 0 } { return }

    catch { RMSL31xStart $FT2::conn_type $FT2::com_port $FT2::com_baud } result
    if { $result == 0 } {
        logbox_output "\[$FT2::conn_type\]: Open failed!\n"
    } else {
        logbox_output "\[$FT2::conn_type\]: open $arg1 at $arg2 successed.\n"

        set ui::status_com "$FT2::com_port OPENED, $arg2 bps"
        .statusbar.com_stat configure -foreground green

        set FT2::com_available  1

        after 100 rmsl31x_get_status
    }
}

proc rmsl31x_stop {} {
    set FT2::com_available  0

    set ui::status_com "$FT2::com_port CLOSED"
    .statusbar.com_stat configure -foreground red

    set_board_status "discon"
    RMSL31xStop
}

proc rmsl31x_get_status {} {
    global BOARD_STATUS_BUSY

    # no connection ?
    if { $FT2::com_available == 0} { return }
     # board busy ?
    if { $FT2::board_status == $BOARD_STATUS_BUSY} { return }

    catch { RMSL31xSendCommand 0x11 } res
    if { $res <= 0} {
        logbox_output "send command failed, please check connection!\n"
        return
    }

    # 210ms
    set FT2::board_timeout 7
    set_board_status "busy"
}

proc rmsl31x_send_command { id data timeout } {
    global BOARD_STATUS_READY
    # no connection ?
    if { $FT2::com_available == 0} {
        logbox_output "Connection not opened!\n"
        return
    }
     # board ready ?
    if { $FT2::board_status != $BOARD_STATUS_READY} {
        logbox_output "Board not ready!\n"
        return
    }

    catch { RMSL31xSendCommand $id $data } res
    if { $res <= 0} {
        logbox_output "send command failed, please check connection!\n"
        return
    }

    set FT2::board_timeout [expr $timeout / 30 ]
    set_board_status "busy"
}

proc rmsl31x_command_getversion { } {
    rmsl31x_send_command "0x30" " " "10000"
}

proc rmsl31x_command_enroll_single { } {
    set i 0

    # admin
    set data "0x00 "

    # user name
    while {$i < 32} {
        set char [string index $FT2::enroll_username $i]
        if { $char == "" } { append data "0x00 " } else { append data [format "0x%02X " [scan $char %c]] }
        incr i
    }
    # face_direction
    append data "0x00 "

    # time out 10s
    append data "0x0a "

    rmsl31x_send_command "0x1d" $data "10000"
}

proc rmsl31x_command_delete_all { } {
    rmsl31x_send_command "0x21" " " "10000"
}

proc rmsl31x_command_verify { } {
    rmsl31x_send_command "0x12" "0x00 0x010" "10000"
}

proc post_verify_process { } {

    if { $FT2::verify_auto == 1 } {
        if { $FT2::verify_cntdown > 0 } {
            incr FT2::verify_cntdown -1

            if { $FT2::verify_cntdown == 0 } {
                logbox_output "������� $FT2::verify_cnt ���\n"
                save_capture_statistics
                return
            }
             after 100 rmsl31x_command_verify
        }
    } else {
        set FT2::verify_cntdown 0
    }
}

proc handle_reply_verify { data } {
    set res [lindex $data 1]
    if { $res == 0 } {
        set uid [lindex $data 3]

        set FT2::verify_userstate $uid
        set FT2::verify_livestate 1
        logbox_output "\[Verify\] �û� $uid\n"
    }

    if { $res == 8 }  {
        set FT2::verify_userstate -1
        set FT2::verify_livestate 1
        logbox_output "\[Verify\] δ֪�û�\n"
    }
    if { $res == 12 } {
        set FT2::verify_userstate -1
        set FT2::verify_livestate 0
        logbox_output "\[Verify\] ������ʧ��\n"
    }

    update_verify_status

    if { $FT2::capture_enable == 1 } {
        source VerifytDoneCallback.tcl
    }

    after 100 post_verify_process
}

proc handle_reply_enroll_single { data } {
    set res [lindex $data 1]
    if { $res == 0 } {
        set uid [lindex $data 3]
        logbox_output "¼��ɹ� �û�ID $uid\n"
    } else {
        logbox_output "¼��ʧ�ܣ� $res\n"
    }
}

proc handle_reply_message { data } {
    set mid [lindex $data 0]

    if { $mid == 0x11 } {
        logbox_output "\[State\]\n"
    }
    # verify
    if { $mid == 0x12 } {
        handle_reply_verify $data
    }
    if { $mid == 0x1d } {
        handle_reply_enroll_single $data
    }
    # get verison
    if { $mid == 0x30 } {
        set FT2::board_version [string trim [binary format c* [lrange $data 2 end]]]
        logbox_output "\[Version\] $FT2::board_version\n"
    }
    set_board_status "ready"
}

proc handle_note_message { data } {
    set nid [lindex $data 0]

    if { $nid == 0x1 } {
        set fstat [lindex $data 1]
        set FT2::verify_facestate $fstat

        update_face_status
        logbox_output "\[Face STAT\]: [lindex $ui::values_face_status $fstat]\n"
    }
}

proc check_recv_message {} {
    global BOARD_STATUS_BUSY

    #if { $FT2::board_status != $BOARD_STATUS_BUSY } { return }
    catch { RMSL31xRecvCommand  } bin
    if { $bin == "\xff" } {

        # timeout
        if { $FT2::board_status == $BOARD_STATUS_BUSY } {
            incr FT2::board_timeout -1
            if { $FT2::board_timeout == 0 } {
                logbox_output "Communication timeout!\n"
                set_board_status "discon"
            }
        }
        return
    }

    binary scan $bin cc* type data
    if { $type == 0 } {
        handle_reply_message $data
    }
    if { $type == 1 } {
        handle_note_message $data
    }
}

proc check_window_focus {} {
    if { [string length [focus]]  == 0 } {
        wm attributes . -alpha 0.6
    } else {
        wm attributes . -alpha 1.0
    }
}

# ----------------------------------------------------------------------------------------
# MENUS
proc create_menus {} {
  option add *tearOff false
  . configure -menu [menu .menu]
  .menu add cascade -label "File" -underline 0 -menu [menu .menu.file]
    .menu.file add command -label "New Tab" -underline 0 \
      -accelerator "Ctrl+N" -command {newTab [.nb index current]}
}

# ----------------------------------------------------------------------------------------
# WIDGETS
proc create_widgets {} {

    ttk::frame .main
        ttk::notebook .nb -takefocus 0 -height 10
        ttk::notebook::enableTraversal .nb
            ttk::frame .nb.fconnect
                ttk::labelframe .nb.fconnect.fopen -borderwidth 1 -relief flat -text "Connection to board"
                    set tf .nb.fconnect.fopen
                    ttk::label      $tf.lopen -relief flat -width 10 -textvariable ui::open_label
                    ttk::label      $tf.lspeed -relief flat -width 10 -text "Baud Rate:"
                    ttk::combobox   $tf.cbopen  -values $ui::values_devices -textvariable FT2::com_port
                    ttk::combobox   $tf.cbspeed -values $ui::values_baudrates -textvariable FT2::com_baud
                    ttk::button     $tf.bopen -text "Open" \
                        -takefocus 0 \
                        -command {rmsl31x_start}
                    ttk::button $tf.bclose -text "Close" \
                        -takefocus 0 \
                        -command {rmsl31x_stop}

                    ttk::radiobutton $tf.rbserial -text "Serial" \
                        -variable FT2::conn_type -value "Serial" \
                        -command {select_connection_type}
                    ttk::radiobutton $tf.rbft232  -text "FT232" \
                        -variable FT2::conn_type -value "FT232" \
                        -command {select_connection_type}
                    ttk::button $tf.benum -text "Scan" \
                        -takefocus 0 \
                        -command {enum_connection_devices}
                    grid $tf.lopen -padx 5 -pady 5 -in $tf -row 0 -column 0 -sticky w
                    grid $tf.cbopen -padx 5 -pady 5 -in $tf -row 0 -column 1 -sticky w
                    grid $tf.bopen -padx 5 -pady 5 -in $tf -row 0 -column 2 -sticky e
                    grid $tf.lspeed -padx 5 -pady 5 -in $tf -row 1 -column 0 -sticky w
                    grid $tf.cbspeed -padx 5 -pady 5 -in $tf -row 1 -column 1 -sticky w
                    grid $tf.bclose -padx 5 -pady 5 -in $tf -row 1 -column 2 -sticky e
                    grid $tf.rbserial -padx 5 -pady 5 -in $tf -row 2 -column 0 -sticky w
                    grid $tf.rbft232  -padx 5 -pady 5 -in $tf -row 2 -column 1 -sticky w
                    grid $tf.benum    -padx 5 -pady 5 -in $tf -row 2 -column 2 -sticky e

                    grid columnconfigure $tf $tf.cbopen -weight 1

                ttk::labelframe .nb.fconnect.fsyscon -borderwidth 1 -relief flat -text "System Control"
                    set tf .nb.fconnect.fsyscon
                    ttk::button $tf.breset -text "Reset Board" -takefocus 0 -command { logbox_output "not support yet..\n" }
                    ttk::button $tf.bstat -text "Get Status" -takefocus 0 -command { rmsl31x_get_status }
                    ttk::entry  $tf.ever -textvariable FT2::board_version
                    ttk::button $tf.bver -text "Get Version" -takefocus 0 -command { rmsl31x_command_getversion }

                    ttk::checkbutton $tf.ckftpwr -text "FT232 Power" -variable FT2::ft232_power -command { ft232_set_power }

                    grid $tf.breset  -padx 5 -pady 5 -in $tf -row 0 -column 0 -sticky w
                    grid $tf.bstat   -padx 5 -pady 5 -in $tf -row 0 -column 1 -sticky w
                    grid $tf.ckftpwr -padx 5 -pady 5 -in $tf -row 0 -column 2 -sticky w
                    grid $tf.bver    -padx 5 -pady 5 -in $tf -row 1 -column 0 -sticky w
                    grid $tf.ever    -padx 5 -pady 5 -in $tf -row 1 -column 1 -sticky w

                    
            grid .nb.fconnect.fopen   -in .nb.fconnect -padx 5 -pady 5 -row 0 -column 0 -sticky nswe
            grid .nb.fconnect.fsyscon -in .nb.fconnect -padx 5 -pady 5 -row 1 -column 0 -sticky nswe
            grid columnconfigure .nb.fconnect $tf -weight 1
            .nb insert end .nb.fconnect -text "Connection"

            ttk::frame .nb.fenroll
                ttk::labelframe .nb.fenroll.fuser -borderwidth 1 -relief flat -text "User Info"
                    set tf .nb.fenroll.fuser
                    ttk::label       $tf.luname -relief flat -width 10 -text "User Name"
                    ttk::entry       $tf.euname -textvariable FT2::enroll_username
                    ttk::checkbutton $tf.ckadmin -text "Is Admin" -variable FT2::enroll_isadmin
                    ttk::combobox    $tf.cbfdir  -values $ui::values_facedirs -width 10 -textvariable FT2::enroll_facedir

                    grid $tf.luname  -padx 5 -pady 5 -in $tf -row 0 -column 0 -sticky w
                    grid $tf.euname  -padx 5 -pady 5 -in $tf -row 0 -column 1 -sticky w
                    grid $tf.ckadmin  -padx 5 -pady 5 -in $tf -row 0 -column 2 -sticky w
                    grid $tf.cbfdir  -padx 5 -pady 5 -in $tf -row 0 -column 3 -sticky w

                ttk::labelframe .nb.fenroll.ferlcon -borderwidth 1 -relief flat -text "Enroll user"
                    set tf .nb.fenroll.ferlcon
                    ttk::button $tf.berlsgl -text "Enroll Single" -takefocus 0 -command { rmsl31x_command_enroll_single }
                    ttk::button $tf.bdelall -text "Delete All" -takefocus 0 -command { rmsl31x_command_delete_all }
                    grid $tf.berlsgl  -padx 5 -pady 5 -in $tf -row 0 -column 0 -sticky w
                    grid $tf.bdelall  -padx 5 -pady 5 -in $tf -row 0 -column 1 -sticky w
            grid .nb.fenroll.fuser -in .nb.fenroll -padx 5 -pady 5 -row 0 -column 0 -sticky nswe
            grid .nb.fenroll.ferlcon -in .nb.fenroll -padx 5 -pady 5 -row 1 -column 0 -sticky nswe
            grid columnconfigure .nb.fenroll $tf -weight 1
            .nb insert end .nb.fenroll -text "Enroll"

            ttk::frame .nb.fverify
                ttk::labelframe .nb.fverify.fvercon -borderwidth 1 -relief flat -text "Verify Control"
                    set tf .nb.fverify.fvercon
                    ttk::button $tf.bverstart -text "Start Verify" -takefocus 0 -command { start_verify }
                    ttk::checkbutton $tf.ckverauto -text "Continuous" -variable FT2::verify_auto
                    ttk::entry       $tf.ecnt -width 10 -textvariable FT2::verify_cnt
                    ttk::label       $tf.lcntdn -relief solid -width 8 -anchor c -textvariable FT2::verify_cntdown
                    grid $tf.bverstart  -padx 5 -pady 5 -in $tf -row 0 -column 0 -sticky w
                    grid $tf.ckverauto  -padx 5 -pady 5 -in $tf -row 0 -column 1 -sticky w
                    grid $tf.lcntdn     -padx 5 -pady 5 -in $tf -row 0 -column 2 -sticky w
                    grid $tf.ecnt       -padx 5 -pady 5 -in $tf -row 0 -column 3  -sticky e
                    grid columnconfigure $tf $tf.ecnt -weight 1

                ttk::labelframe .nb.fverify.fverstat -borderwidth 1 -relief flat -text "Verify State"
                    set tf .nb.fverify.fverstat
                    ttk::label      $tf.lfacestat1 -relief flat  -width 10 -text "����״̬"
                    ttk::label      $tf.lfacestat2 -relief solid -anchor c -font { -18 } -width 20 -background blue -foreground white -textvariable ui::state_face
                    ttk::label      $tf.llivestat1 -relief flat  -width 10 -text "����״̬"
                    ttk::label      $tf.llivestat2 -relief solid -anchor c -font { -18 } -width 20 -background blue -foreground white -textvariable ui::state_live
                    ttk::label      $tf.luserstat1 -relief flat  -width 10 -text "�û�״̬"
                    ttk::label      $tf.luserstat2 -relief solid -anchor c -font { -18 } -width 20 -background blue -foreground white -textvariable ui::state_user
                    grid $tf.lfacestat1  -padx 5 -pady 5 -in $tf -row 0 -column 0 -sticky we
                    grid $tf.lfacestat2  -padx 5 -pady 5 -in $tf -row 0 -column 1 -sticky we
                    grid $tf.llivestat1  -padx 5 -pady 5 -in $tf -row 1 -column 0 -sticky we
                    grid $tf.llivestat2  -padx 5 -pady 5 -in $tf -row 1 -column 1 -sticky we
                    grid $tf.luserstat1  -padx 5 -pady 5 -in $tf -row 2 -column 0 -sticky we
                    grid $tf.luserstat2  -padx 5 -pady 5 -in $tf -row 2 -column 1 -sticky we

            grid .nb.fverify.fvercon  -in .nb.fverify -padx 5 -pady 5 -row 0 -column 0 -sticky nswe
            grid .nb.fverify.fverstat -in .nb.fverify -padx 5 -pady 5 -row 1 -column 0 -sticky nswe
            grid columnconfigure .nb.fverify $tf -weight 1
            .nb insert end .nb.fverify -text "Verify"

            if { $ui::enable_capture } {
                ttk::frame .nb.fcapture
                    ttk::labelframe .nb.fcapture.fvercon -borderwidth 1 -relief flat -text "Capture Control"
                        set tf .nb.fcapture.fvercon
                        ttk::button      $tf.bverstart -text "Start Capture" -takefocus 0 -command { start_capture }
                        ttk::checkbutton $tf.ckverauto -text "Continuous" -variable FT2::verify_auto
                        ttk::entry       $tf.ecnt -width 10 -textvariable FT2::verify_cnt
                        ttk::label       $tf.lcntdn -relief solid -width 8 -anchor c -textvariable FT2::verify_cntdown

                        grid $tf.bverstart  -padx 5 -pady 5 -in $tf -row 0 -column 0 -sticky w
                        grid $tf.ckverauto  -padx 5 -pady 5 -in $tf -row 0 -column 1 -sticky w
                        grid $tf.lcntdn     -padx 5 -pady 5 -in $tf -row 0 -column 2 -sticky w
                        grid $tf.ecnt  -padx 5 -pady 5 -in $tf -row 0 -column 3  -sticky e
                        grid columnconfigure $tf $tf.ecnt -weight 1

                    ttk::labelframe .nb.fcapture.flivcon -borderwidth 1 -relief flat -text "Liveness Setting"
                        set tf .nb.fcapture.flivcon
                        ttk::label      $tf.lexplive -relief flat -anchor c -width 8 -text "ģʽ"
                        ttk::combobox   $tf.cbexplive  -values $ui::values_live_status -width 8 -textvariable FT2::expected_livestate
                        grid $tf.lexplive   -padx 1 -pady 1 -in $tf -row 0 -column 0 -sticky w
                        grid $tf.cbexplive  -padx 1 -pady 1 -in $tf -row 0 -column 1 -sticky w

                    ttk::labelframe .nb.fcapture.fcapcon -borderwidth 1 -relief flat -text "Capture Setting"
                        set tf .nb.fcapture.fcapcon
                        #ttk::checkbutton $tf.ckcapen    -text "Capure Enable" -variable FT2::capture_enable

                        ttk::label      $tf.llight  -relief flat -anchor c -width 6 -text "����"
                        ttk::combobox   $tf.cblight -values $ui::values_light  -width 8
                        ttk::label      $tf.lglass  -relief flat -anchor c -width 6 -text "�۾�"
                        ttk::combobox   $tf.cbglass -values $ui::values_glass  -width 10
                        ttk::label      $tf.ldist   -relief flat -anchor c -width 6 -text "����"
                        ttk::combobox   $tf.cbdist  -values $ui::values_distence   -width 8
                        ttk::label      $tf.lmask   -relief flat -anchor c -width 6 -text "�ڵ�"
                        ttk::combobox   $tf.cbmask  -values $ui::values_mask   -width 14
                        ttk::label      $tf.latk    -relief flat -anchor c -width 6 -text "����"
                        ttk::combobox   $tf.cbatk   -values $ui::values_attack -width 8
                        ttk::label      $tf.lmove   -relief flat -anchor c -width 6 -text "��̬"
                        ttk::combobox   $tf.cbmove  -values $ui::values_move   -width 10
                        ttk::label      $tf.lmkup   -relief flat -anchor c -width 6 -text "��ױ"
                        ttk::combobox   $tf.cbmkup  -values $ui::values_makeup -width 8
                        ttk::label      $tf.lrepl   -relief flat -anchor c -width 6 -text "�滻"
                        ttk::combobox   $tf.cbrepl  -values $ui::values_replace -width 14
                        ttk::label      $tf.lpath   -relief flat -anchor c -width 6 -text "Path"
                        ttk::entry      $tf.epath   -textvariable FT2::capture_path

                        ttk::frame $tf.fsavpath -borderwidth 0
                            ttk::label      $tf.fsavpath.luid -relief flat -anchor c -width 6 -text "ID"
                            ttk::entry      $tf.fsavpath.euid  -width 10 -textvariable FT2::capture_uid
                            ttk::button     $tf.fsavpath.baoto -text "Auto Path" -takefocus 0 -command { format_capture_path }
                            ttk::button     $tf.fsavpath.bset  -text "Set Path"  -takefocus 0 -command { set_capture_path }
                            ttk::button     $tf.fsavpath.bopen -text "Open Path" -takefocus 0 -command { open_capture_path }
                            pack $tf.fsavpath.luid  -in $tf.fsavpath -side left -padx 1
                            pack $tf.fsavpath.euid  -in $tf.fsavpath -side left -padx 1
                            pack $tf.fsavpath.baoto -in $tf.fsavpath -side left -padx 1
                            pack $tf.fsavpath.bset  -in $tf.fsavpath -side left -padx 1
                            pack $tf.fsavpath.bopen -in $tf.fsavpath -side left -padx 1

                        grid $tf.llight   -in $tf  -padx 1 -pady 2 -in $tf -row 1 -column 0 -sticky w
                        grid $tf.cblight  -in $tf  -padx 1 -pady 2 -in $tf -row 1 -column 1 -sticky w
                        grid $tf.lglass   -in $tf  -padx 1 -pady 2 -in $tf -row 1 -column 2 -sticky w
                        grid $tf.cbglass  -in $tf  -padx 1 -pady 2 -in $tf -row 1 -column 3 -sticky w
                        grid $tf.ldist    -in $tf  -padx 1 -pady 2 -in $tf -row 1 -column 4 -sticky w
                        grid $tf.cbdist   -in $tf  -padx 1 -pady 2 -in $tf -row 1 -column 5 -sticky w
                        grid $tf.latk     -in $tf  -padx 1 -pady 2 -in $tf -row 2 -column 0 -sticky w
                        grid $tf.cbatk    -in $tf  -padx 1 -pady 2 -in $tf -row 2 -column 1 -sticky w
                        grid $tf.lmove    -in $tf  -padx 1 -pady 2 -in $tf -row 2 -column 2 -sticky w
                        grid $tf.cbmove   -in $tf  -padx 1 -pady 2 -in $tf -row 2 -column 3 -sticky w
                        grid $tf.lmkup    -in $tf  -padx 1 -pady 2 -in $tf -row 2 -column 4 -sticky w
                        grid $tf.cbmkup   -in $tf  -padx 1 -pady 2 -in $tf -row 2 -column 5 -sticky w
                        grid $tf.lrepl    -in $tf  -padx 1 -pady 2 -in $tf -row 3 -column 0 -sticky w
                        grid $tf.cbrepl   -in $tf  -padx 1 -pady 2 -in $tf -row 3 -column 1 -sticky w  -columnspan 2
                        grid $tf.lmask    -in $tf  -padx 1 -pady 2 -in $tf -row 3 -column 4 -sticky w
                        grid $tf.cbmask   -in $tf  -padx 1 -pady 2 -in $tf -row 3 -column 5 -sticky w
                        grid $tf.fsavpath -in $tf  -padx 1 -pady 2 -in $tf -row 4 -column 0 -sticky we -columnspan 6
                        grid $tf.lpath    -in $tf  -padx 1 -pady 2 -in $tf -row 5 -column 0 -sticky w
                        grid $tf.epath    -in $tf  -padx 1 -pady 2 -in $tf -row 5 -column 1 -sticky we -columnspan 5


                grid .nb.fcapture.fvercon  -in .nb.fcapture -padx 5 -pady 5 -row 0 -column 0 -sticky nswe
                grid .nb.fcapture.flivcon  -in .nb.fcapture -padx 5 -pady 5 -row 1 -column 0 -sticky nswe
                grid .nb.fcapture.fcapcon  -in .nb.fcapture -padx 5 -pady 5 -row 2 -column 0 -sticky nswe
                grid columnconfigure .nb.fcapture $tf -weight 1
                .nb insert end .nb.fcapture -text "Capture"
            }

        # grid notebook and marks in the right pane frame
        grid .nb     -in .main -row 0 -column 0 -sticky nswe
        grid rowconfigure    .main .nb -weight 1
        grid columnconfigure .main .nb -weight 1


    ttk::frame .statusbar -borderwidth 1 -relief sunken
        ttk::label .statusbar.com_stat    -relief flat -anchor w -textvariable ui::status_com
        ttk::label .statusbar.board_stat  -relief flat -anchor w -textvariable ui::status_board
        #ttk::label .modified -relief flat -anchor e -text "modified"
        ttk::sizegrip .sizegrip
        grid .statusbar.com_stat   -padx 1 -pady 1 -in .statusbar -row 0 -column 0 -sticky we
        grid .statusbar.board_stat -padx 1 -pady 1 -in .statusbar -row 0 -column 1 -sticky we
        #grid .modified -in .statusbar -row 0 -column 2 -sticky e
        grid .sizegrip -in .statusbar -row 0 -column 3 -sticky e
        grid columnconfigure .statusbar .statusbar.com_stat -weight 1
        grid columnconfigure .statusbar .statusbar.board_stat -weight 1

    ttk::frame .log -borderwidth 1 -relief sunken
        tk::text .log.text -relief sunken -highlightthickness 0 -takefocus 1 -height 10 \
          -xscrollcommand [list .log.xscroll set] -yscrollcommand [list .log.yscroll set]

        ttk::scrollbar .log.yscroll -orient vertical   -command [list .log.text yview]
        ttk::scrollbar .log.xscroll -orient horizontal -command [list .log.text xview]
        grid .log.text     -in .log -row 0 -column 0 -sticky nswe
        grid .log.yscroll  -in .log -row 0 -column 1 -sticky ns
        grid .log.xscroll  -in .log -row 1 -column 0 -sticky we -columnspan 2
        grid rowconfigure    .log .log.text  -weight 1
        grid columnconfigure .log .log.text  -weight 1

    #grid .fopen     -in . -row 0 -column 0 -sticky we
    grid .main      -in . -row 1 -column 0 -sticky nswe
    grid .log       -in . -row 2 -column 0 -sticky swe
    grid .statusbar -in . -row 3 -column 0 -sticky we
    grid rowconfigure    . .main -weight 1
    grid columnconfigure . .main -weight 1

    .nb.fconnect.fopen.rbserial invoke
    .nb.fconnect.fopen.cbspeed current 0
    
    if { $ui::enable_capture } {
        .nb.fcapture.fcapcon.cblight  current 0
        .nb.fcapture.fcapcon.cbglass  current 0
        .nb.fcapture.fcapcon.cbmask   current 0
        .nb.fcapture.fcapcon.cbatk    current 0
        .nb.fcapture.fcapcon.cbmove   current 0
        .nb.fcapture.fcapcon.cbmkup   current 0
        .nb.fcapture.fcapcon.cbrepl   current 0
        .nb.fcapture.fcapcon.cbdist   current 0
    }
}

# ----------------------------------------------------------------------------------------
# MAIN PROGRAM
# set exit_prog 0
catch { load [file join [pwd] "lib/rmsl31x.dll"] } result
if { [string first "couldn't" $result] != -1 } {
  tk_dialog .dialog1 "DLL not found" {Press OK to close application.} info 0 OK
  exit 0
}

create_widgets
create_menus

# window manager instructions.
wm title    . "RMSL31x FaceTool2"
wm minsize  . 480 500
wm geometry . 480x500
wm protocol . WM_DELETE_WINDOW {exitpgm}
#wm attributes . -toolwindow 1 -alpha 0.5

set ui::status_com "CLOSED"
.statusbar.com_stat configure -foreground red
set_board_status "discon"

# ----------------------------------------------------------------------------------------
# Periodic functions
proc every {ms body} {eval $body; after $ms [info level 0]}
every 30 { check_recv_message }
#every 200 { check_window_focus }