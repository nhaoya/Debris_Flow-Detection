#!/bin/sh -e
[ -z "$DEBUG" ] || set -x
echo "########## fio-3.28: build ##########"
cd /home/zhengjian/buildroot/buildroot
PATH="/home/zhengjian/buildroot/buildroot/output/rockchip_rv1126_rv1109/host/bin:/home/zhengjian/buildroot/buildroot/output/rockchip_rv1126_rv1109/host/sbin:/home/zhengjian/work/rv1126_ipc_linux_in_for_push/tools/linux/toolchain/arm-rockchip830-linux-gnueabihf/bin:/home/zhengjian/work/rv1126_ipc_linux/bin:/home/zhengjian/repo-tool:/home/zhengjian/work/1106_in/tools/linux/toolchain/arm-rockchip830-linux-uclibcgnueabihf/bin:/home/zhengjian/work/1106_in/tools/linux/toolchain/arm-rockchip830-linux-uclibcgnueabihf/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/games:/usr/local/games:/snap/bin" RecoveryNoUi=true /usr/bin/make -j65 -C /home/zhengjian/buildroot/buildroot/output/rockchip_rv1126_rv1109/build/fio-3.28
