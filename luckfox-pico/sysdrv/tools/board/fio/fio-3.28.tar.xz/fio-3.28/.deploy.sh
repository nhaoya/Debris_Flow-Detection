#!/bin/sh -e
[ -z "$DEBUG" ] || set -x
echo "########## fio-3.28: deploy ##########"
cd /home/zhengjian/buildroot/buildroot
cd /home/zhengjian/buildroot/buildroot/output/rockchip_rv1126_rv1109/target
tar --no-recursion --ignore-failed-read -cf /home/zhengjian/buildroot/buildroot/output/rockchip_rv1126_rv1109/build/fio-3.28/fio-3.28.tar -T /home/zhengjian/buildroot/buildroot/output/rockchip_rv1126_rv1109/build/fio-3.28/.files-list-target.txt
adb shell true >/dev/null
adb push /home/zhengjian/buildroot/buildroot/output/rockchip_rv1126_rv1109/build/fio-3.28/fio-3.28.tar /tmp/
adb shell tar xvf /tmp/fio-3.28.tar
