#!/bin/sh -e
[ -z "$DEBUG" ] || set -x
echo "########## fio-3.28: target install ##########"
cd /home/zhengjian/buildroot/buildroot
touch /home/zhengjian/buildroot/buildroot/output/rockchip_rv1126_rv1109/build/fio-3.28/.stamp_installed
if [ -r /home/zhengjian/buildroot/buildroot/output/rockchip_rv1126_rv1109/build/fio-3.28/.files-list-target.txt ]; then cd /home/zhengjian/buildroot/buildroot/output/rockchip_rv1126_rv1109/target; cat /home/zhengjian/buildroot/buildroot/output/rockchip_rv1126_rv1109/build/fio-3.28/.files-list-target.txt | xargs md5sum /dev/null > /home/zhengjian/buildroot/buildroot/output/rockchip_rv1126_rv1109/build/fio-3.28/.md5 2>/dev/null || true; cd -; fi
/usr/bin/install -D /home/zhengjian/buildroot/buildroot/output/rockchip_rv1126_rv1109/build/fio-3.28/fio /home/zhengjian/buildroot/buildroot/output/rockchip_rv1126_rv1109/target/usr/bin/fio
rm -f -rf  /home/zhengjian/buildroot/buildroot/output/rockchip_rv1126_rv1109/target/share/info/dir
if test -n "" ; then rm -f -f  ; fi
cd /home/zhengjian/buildroot/buildroot/output/rockchip_rv1126_rv1109/target; find . \( -type f -o -type l \) -cnewer /home/zhengjian/buildroot/buildroot/output/rockchip_rv1126_rv1109/build/fio-3.28/.stamp_installed | tee /home/zhengjian/buildroot/buildroot/output/rockchip_rv1126_rv1109/build/fio-3.28/.files-list-target.txt | tar --no-recursion --ignore-failed-read -cf /home/zhengjian/buildroot/buildroot/output/rockchip_rv1126_rv1109/build/fio-3.28/fio-3.28.tar -T -; true;
cd /home/zhengjian/buildroot/buildroot/output/rockchip_rv1126_rv1109/target; if [ -r /home/zhengjian/buildroot/buildroot/output/rockchip_rv1126_rv1109/build/fio-3.28/.md5 ]; then md5sum -c /home/zhengjian/buildroot/buildroot/output/rockchip_rv1126_rv1109/build/fio-3.28/.md5 2>&1 | grep "FAILED$" | cut -d':' -f1 > /home/zhengjian/buildroot/buildroot/output/rockchip_rv1126_rv1109/build/fio-3.28/.files-list-target-update.txt; fi
